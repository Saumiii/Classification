# Saumya Gupta

COGx Document Classifier - Classify the documents into predefined template based categories
